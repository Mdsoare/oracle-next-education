# Challenge - HighLight

<img src=./assets/img/alura-challenges.svg alt="Logotipo da Alura" title="Logo da Alura">
<br>

[Challenge](https://www.alura.com.br/challenges/front-end/semana-01-do-figma-ao-html-e-css) para implementar a biblioteca [HighLight](https://highlightjs.org/) em 3 semanas. As ferramentas de apoio são:
- [Trello](https://trello.com/b/19ouy4RA/desafio-front-end-semana-1) 
- [Figma](https://www.figma.com/file/tvFEYhVfZTjdJ5P24RGV21/Alura-Challenge---Desafio-1---L%C3%B3gica?type=design&node-id=0-1&mode=design&t=2fmTvlLYi81VQi4t-0)
- [Video 1ª Semana](https://youtu.be/Yk2gRJtkQpM)
- [Video 2ª Semana](https://youtu.be/Efzk5uEmcYU)
- [Video 3ª Semana](https://youtu.be/6JO9ArtZifQ)

## Publicar solução:
##### Passo-a-passo para gerar a página do repositório:

- O repositório deve ser **Public**;
- No repositório do projeto clique em **Settings**;
- Em seguida, no menu lateral esquerdo, vá em **Pages**;
- No lado direito vá em **Branch** e ajuste a branch para a que deseja publicar, no meu caso **Main**, opcionalmente altere de **/root** para **/docs** e clique em **Save**;
- Aguarde a página ser gerada após a validação do próprio GitHub;
- Se tudo estiver correto, ao final, logo abaixo do **GitHub Pages** será disponibilizado o link;
- Agora é só clicar em **Visit Site** para ver a página publicada;

<br>

## Redes Socias

[![PerfilDIO](https://img.shields.io/badge/DIO-0077B5?style=for-the-badge&logo=dio&logoColor=white)](https://web.dio.me/users/marcelo_soares92)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/Mdsoare/)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/marcelodsoares/) 

<table>
  <tr>
    <td>
      <img width="80px" align="center" src="https://avatars.githubusercontent.com/Mdsoare"/>
    </td>
    <td align="left">
      <a href="https://www.linkedin.com/in/marcelodsoares/">
        <span><b>Marcelo Soares</b></span>
      </a>
      <br>
      <span>Analista de Sistemas</span>
    </td>
  </tr>
</table>

<br>

## Referências 🔎

- [W3schools](https://www.w3schools.com/);
- [MDN](https://developer.mozilla.org/pt-BR/);
- [Carbon](https://carbon.now.sh/);
- [Gist](https://gist.github.com/);
- [Alura - Artigos Front-End](https://www.alura.com.br/artigos/como-colocar-projeto-no-ar-com-github-pages).
