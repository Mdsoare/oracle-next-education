const selectors = {
    campoBusca: '.busca',
    linguagem: '.escolha-linguagem',
    divDestaque: '.highlight-div',
    botaoHighlight: '.highlight-div-botao',
    areaDoCodigo: '.highlight-div-texto',
    highlightDivOut: '.highlight-div-out',
    highlightDivTextOut: '.highlight-div-texto-out',
    reset: '.reset',
    escolherCor: '.escolha-cor',
    nomeProjeto: '.nome-do-projeto',
    descricaoProjeto: '.descricao-do-projeto',
    exibeNomeDescricao: '.nome-descricao-out',
    salvarProjeto: '.salvar-projeto'
};

const elements = {};
for (const key in selectors) {
    elements[key] = document.querySelector(selectors[key]);
}

function aplicaHighlight() {
    if (!elements.linguagem.value) {
        alert('Por favor, escolha uma linguagem.');
        return;
    }

    exibeSaida();
    const codigo = elements.areaDoCodigo.textContent;
    elements.highlightDivTextOut.innerHTML = `<code class="hljs ${elements.linguagem.value}" contenteditable="false" aria-label="Editor de código">${codigo}</code>`;
    hljs.highlightElement(elements.highlightDivTextOut.querySelector('code'));
    nomeDescricao();
}

function exibeSaida() {
    elements.divDestaque.style.display = 'none';
    elements.botaoHighlight.style.display = 'none';
    elements.highlightDivOut.style.display = 'flex';
    elements.reset.style.display = 'flex';
    elements.reset.classList.add('highligth-div-botao');
}

function limpar() {
    window.location.reload();
}

function search() {
    const buscaTexto = elements.campoBusca.value;
    if (buscaTexto !== "") {
        let regExp = new RegExp(buscaTexto, 'gi');
        elements.areaDoCodigo.innerHTML = elements.areaDoCodigo.textContent.replace(regExp, "<mark>$&</mark>");
        elements.highlightDivTextOut.innerHTML = elements.highlightDivTextOut.textContent.replace(regExp, "<mark>$&</mark>");
    } else {
        elements.areaDoCodigo.innerHTML = elements.areaDoCodigo.textContent;
        elements.highlightDivTextOut.innerHTML = elements.highlightDivTextOut.textContent;
    }
}

elements.campoBusca.addEventListener('keyup', search);

function atualizarCor() {
    const novaCor = elements.escolherCor.value;

    elements.divDestaque.style.backgroundColor = novaCor;
    elements.highlightDivOut.style.backgroundColor = novaCor;
}

elements.escolherCor.addEventListener('input', atualizarCor);
atualizarCor();

function nomeDescricao() {
    const nome = elements.nomeProjeto.value;
    const descricao = elements.descricaoProjeto.value;

    const h2Nome = document.createElement('h2');
    h2Nome.textContent = nome;

    const pDescricao = document.createElement('p');
    pDescricao.textContent = descricao;

    elements.exibeNomeDescricao.appendChild(h2Nome);
    elements.exibeNomeDescricao.appendChild(pDescricao);
}

async function getCodeImage() {
    try {
        const canvas = await html2canvas(elements.highlightDivOut, {
            backgroundColor: 'rgba(171, 184, 195, 1)',
        });

        const imageUrl = canvas.toDataURL('image/png');
        const fileName = prompt('Digite o nome da imagem (sem a extensão .png):');
        if (!fileName) {
            console.warn('Nome de arquivo inválido. O download foi cancelado.');
            return;
        }

        const fullFileName = fileName + '.png';
        const downloadLink = document.createElement('a');
        downloadLink.href = imageUrl;
        downloadLink.download = fullFileName;
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
    } catch (error) {
        console.error('Erro ao gerar a imagem:', error);
    }
}
